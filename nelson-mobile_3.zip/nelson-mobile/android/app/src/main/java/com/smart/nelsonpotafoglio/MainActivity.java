package com.smart.nelsonpotafoglio;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
