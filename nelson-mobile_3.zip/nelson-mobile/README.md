# NELSON × Potafoglio — Mobile App

This is the frontend, rebuilt as a real, store-shippable app via Vite +
Capacitor — no more in-browser Babel or CDN React (that was fine for a
quick preview, but app stores reject it and it's slow on real devices).

## What changed from the prototype

- **Before**: one 6,850-line HTML file, React/Babel loaded from `unpkg.com`
  at runtime, JSX compiled in the browser on every load.
- **Now**: proper ES module source (`src/App.jsx`, `src/main.jsx`),
  React bundled from npm, JSX compiled once at build time by Vite,
  output to `www/` as optimized static assets (216 KB gzipped JS).
  Wrapped by Capacitor into real `android/` (Android Studio) and
  `ios/` (Xcode) native projects.

Functionally it's the same app you already have wired to the backend —
this only changes *how it's built and packaged*, not what it does.

## Run it locally (same as before, just via Vite now)

```bash
npm install
npm run dev        # http://localhost:5173, hot reload
```

Set the backend URL before building if it's not on localhost:4000 — edit
`index.html` and add before the module script tag:
```html
<script>window.NELSON_API_BASE = 'https://your-backend.example.com';</script>
```

## Build for web / Capacitor

```bash
npm run build       # outputs to www/
npx cap sync         # copies www/ into android/ and ios/ native projects
```

## Android — what's left (needs your machine)

1. Install [Android Studio](https://developer.android.com/studio).
2. `npx cap open android` — opens `android/` in Android Studio.
3. Let Gradle sync (first time takes a while — downloads the Android SDK
   build tools, which needs internet access this sandbox doesn't have).
4. **Generate a signing key**: Build → Generate Signed Bundle/APK → Android
   App Bundle → create a new keystore. **Back this up** — losing it means
   you can never update the app on Play Store again.
5. Build → Generate Signed Bundle/APK → produces the `.aab` file Play
   Console wants.
6. In [Play Console](https://play.google.com/console): create the app
   listing, fill in the Data Safety form (be accurate — you're handling
   money and KYC data), upload screenshots + feature graphic, set content
   rating, upload the `.aab`, submit for review.

## iOS — what's left (needs a Mac)

1. On a Mac, install Xcode.
2. `npx cap open ios` — opens `ios/App/App.xcworkspace` (not the .xcodeproj).
3. In Xcode: set your Apple Developer Team under Signing & Capabilities.
4. Product → Archive → Distribute App → App Store Connect.
5. In [App Store Connect](https://appstoreconnect.apple.com): create the
   listing, fill in the Privacy Nutrition Label, upload screenshots per
   device size, submit for review (or push to TestFlight first).

## Before submitting to either store

- Point `NELSON_API_BASE` at your real deployed backend, not localhost.
- Set real `PAYSTACK_SECRET_KEY`, `SMILE_IDENTITY_API_KEY`, and
  `FIREBASE_SERVICE_ACCOUNT_JSON` on the backend (see its README) — an app
  that touches real money and identity docs with those stubbed is not
  launch-ready, regardless of how polished the build is.
- App icons and splash screens are still Capacitor's defaults — replace
  `android/app/src/main/res/` and `ios/App/App/Assets.xcassets/` with your
  actual branding before submitting (`@capacitor/assets` can generate all
  sizes from one source image).
- Test on a real device, not just the simulator/emulator — payment flows
  especially.

## What I genuinely could not do from here

I don't have Android Studio, Xcode, a Google Play Console account, an
Apple Developer account, or your signing keys — none of that is available
in this environment, and the store accounts require your own identity/
business verification. Everything up to "open this in Android
Studio/Xcode and click build" is done; the rest needs your machine and
your accounts.
