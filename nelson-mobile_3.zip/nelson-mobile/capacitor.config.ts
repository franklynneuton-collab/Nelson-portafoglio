import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.smart.nelsonpotafoglio',
  appName: 'NELSON x Potafoglio',
  webDir: 'www'
};

export default config;
